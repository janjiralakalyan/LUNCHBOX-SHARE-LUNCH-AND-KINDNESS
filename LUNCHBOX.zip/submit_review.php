<?php
session_start();
include 'connect.php';

// Ensure user is logged in
if (!isset($_SESSION['roll_number'])) {
    die("⚠️ You must be logged in to submit a review.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lunch_id = $_POST['lunch_id'] ?? null;
    $rating   = $_POST['rating'] ?? null;
    $comment  = trim($_POST['comment'] ?? '');
    $accepter_roll = $_SESSION['roll_number'];

    // Validate input
    if (empty($lunch_id) || empty($rating)) {
        die("⚠️ Invalid review data. Please try again.");
    }

    // Check if the lunch exists and was accepted by this user
    $checkQuery = "SELECT * FROM shared_lunches WHERE id = ? AND accepted_by = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("is", $lunch_id, $accepter_roll);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        die("⚠️ Invalid lunch or you are not authorized to review this lunch.");
    }

    // Get sharer roll number
    $lunch = $result->fetch_assoc();
    $sharer_roll = $lunch['roll_number'];

    // Insert review
    $insertQuery = "INSERT INTO reviews (lunch_id, sharer_roll, accepter_roll, rating, comment) 
                    VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insertQuery);
    $stmt->bind_param("issis", $lunch_id, $sharer_roll, $accepter_roll, $rating, $comment);

    if ($stmt->execute()) {
        echo "✅ Review submitted successfully!";
        header("Location: dashboard.php"); // redirect to dashboard
        exit();
    } else {
        echo "❌ Error submitting review: " . $conn->error;
    }
} else {
    echo "⚠️ Invalid request method.";
}
?>
<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['roll_number'])) {
    header("Location: login.html");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['lunch_id'])) {
    $roll_number = $_SESSION['roll_number'];
    $lunch_id = intval($_POST['lunch_id']);

    // Verify that this lunch belongs to the sharer
    $checkQuery = "SELECT * FROM shared_lunches WHERE id = ? AND roll_number = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("is", $lunch_id, $roll_number);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Delete the lunch
        $deleteQuery = "DELETE FROM shared_lunches WHERE id = ?";
        $stmt = $conn->prepare($deleteQuery);
        $stmt->bind_param("i", $lunch_id);
        if ($stmt->execute()) {
            header("Location: dashboard.php?msg=deleted");
            exit();
        } else {
            echo "Error cancelling shared lunch.";
        }
    } else {
        echo "Invalid request.";
    }
} else {
    echo "Invalid request.";
}
?>
<?php
session_start();
include 'connect.php';

// Check if user is logged in
if (!isset($_SESSION['roll_number'])) {
    echo "⚠️ You must be logged in to accept lunch.";
    exit();
}

// Validate sharer's roll number
if (!isset($_GET['sharer_roll'])) {
    echo "❌ Invalid request.";
    exit();
}

$sharer_roll = $_GET['sharer_roll'];
$accepter_roll = $_SESSION['roll_number'];

// Prevent accepting own lunch
if ($sharer_roll === $accepter_roll) {
    echo "⚠️ You cannot accept your own lunch.";
    exit();
}

// Check if lunch exists and is available
$sql = "SELECT * FROM shared_lunches WHERE roll_number = ? AND status = 'available'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $sharer_roll);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "❌ Lunch not available or already accepted.";
    exit();
}

// Update lunch status
$update_sql = "UPDATE shared_lunches SET status = 'accepted', accepted_by = ? WHERE roll_number = ? AND status = 'available'";
$update_stmt = $conn->prepare($update_sql);
$update_stmt->bind_param("ss", $accepter_roll, $sharer_roll);

if ($update_stmt->execute()) {
    header("Location: findlunch.php?success=1");
    exit();
} else {
    echo "⚠️ Error accepting lunch: " . $conn->error;
}
?>
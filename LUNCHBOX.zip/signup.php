<?php
include 'connect.php';

$message = "";
$messageType = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $roll_number = trim($_POST['roll_number']);
    $phone = trim($_POST['phone']);
    $password = trim($_POST['password']);

    if (empty($name) || empty($roll_number) || empty($phone) || empty($password)) {
        $message = "⚠️ Please fill all fields!";
        $messageType = "error";
    } else {

        // 🔴 Check if roll number already exists FIRST
        $checkSql = "SELECT id FROM users WHERE roll_number = ?";
        $checkStmt = $conn->prepare($checkSql);
        $checkStmt->bind_param("s", $roll_number);
        $checkStmt->execute();
        $checkStmt->store_result();

        if ($checkStmt->num_rows > 0) {
            $message = "⚠️ Roll number already registered. Please login.";
            $messageType = "error";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $sql = "INSERT INTO users (name, roll_number, phone, password) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);

            // 🔴 Always check prepare()
            if (!$stmt) {
                $message = "❌ Something went wrong. Please try again later.";
                $messageType = "error";
            } else {
                $stmt->bind_param("ssss", $name, $roll_number, $phone, $hashedPassword);

                if ($stmt->execute()) {
                    $message = "✅ Account created successfully!";
                    $messageType = "success";
                } else {
                    $message = "❌ Unable to create account. Try again.";
                    $messageType = "error";
                }

                $stmt->close();
            }
        }

        $checkStmt->close();
        $conn->close();
    }
}
?>

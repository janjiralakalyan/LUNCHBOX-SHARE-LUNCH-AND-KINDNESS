<?php
$host = "sql100.infinityfree.com";
$user = "if0_39849571";
$pass = "akshyan1109";
$db   = "if0_39849571_lunchbox";

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
?>
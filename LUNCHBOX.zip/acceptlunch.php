<?php
session_start();
include("connect.php");

if (!isset($_SESSION['user_id'])) {
    echo "You must be logged in to accept lunch.";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['lunch_id'])) {
    $lunch_id = intval($_POST['lunch_id']);
    $user_id = $_SESSION['user_id'];

    // Update lunch status to accepted
    $query = "UPDATE shared_lunch SET status='accepted' WHERE id='$lunch_id' AND status='available'";
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('You accepted this lunch!'); window.location.href='dashboard.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
<?php
session_start();
require 'connect.php';

// ✅ Check if user is logged in
if (!isset($_SESSION['roll_number'])) {
    header("Location: login.php");
    exit();
}

// ✅ Get user details
$roll_number = $_SESSION['roll_number'];
$stmt = $conn->prepare("SELECT name, phone FROM users WHERE roll_number = ?");
$stmt->bind_param("s", $roll_number);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo "User not found!";
    exit();
}

// ✅ Handle form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $food_items = trim($_POST['food_items']);
    $location   = trim($_POST['location']);

    if (!empty($food_items) && !empty($location)) {
        $stmt = $conn->prepare("INSERT INTO shared_lunches (name, roll_number, phone, food_items, location, status, created_at) 
                                VALUES (?, ?, ?, ?, ?, 'available', NOW())");
        $stmt->bind_param("sssss", $user['name'], $roll_number, $user['phone'], $food_items, $location);

        if ($stmt->execute()) {
            $success = "✅ Lunch shared successfully!";
        } else {
            $error = "❌ Error: " . $stmt->error;
        }
    } else {
        $error = "❌ Please fill all fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Share Lunch - Lunch Box</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Tailwind -->
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- Lottie -->
  <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
</head>
<body class="bg-gradient-to-br from-gray-900 via-black to-gray-800 text-white min-h-screen flex flex-col">

  <!-- Header -->
  <header class="py-6 text-center border-b border-gray-700">
    <h1 class="text-3xl font-bold text-green-400 tracking-wide">
      🍱 Share Your Lunch
    </h1>
    <p class="text-gray-400">Welcome <b class="text-white"><?php echo htmlspecialchars($user['name']); ?></b> (<?php echo $roll_number; ?>)</p>
  </header>

  <!-- Main Content -->
  <main class="flex-1 flex justify-center items-center p-6">
    <div class="bg-black/40 backdrop-blur-md p-8 rounded-2xl shadow-xl border border-gray-700 w-full max-w-lg">

      <!-- Success / Error Messages -->
      <?php if (isset($success)): ?>
        <div class="mb-4 p-3 bg-green-600/20 text-green-400 rounded-lg border border-green-600">
          <?php echo $success; ?>
        </div>
      <?php endif; ?>

      <?php if (isset($error)): ?>
        <div class="mb-4 p-3 bg-red-600/20 text-red-400 rounded-lg border border-red-600">
          <?php echo $error; ?>
        </div>
      <?php endif; ?>

      <!-- Form -->
      <form method="POST" class="space-y-5">
        <div>
          <label class="block text-sm font-medium text-gray-300">Food Items</label>
          <input type="text" name="food_items" placeholder="Enter food items with description"
                 class="w-full mt-2 px-4 py-3 rounded-lg bg-gray-900 text-gray-100 border border-gray-700 focus:ring-2 focus:ring-green-400 focus:outline-none"
                 required>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-300">Location</label>
          <input type="text" name="location" placeholder="Enter location"
                 class="w-full mt-2 px-4 py-3 rounded-lg bg-gray-900 text-gray-100 border border-gray-700 focus:ring-2 focus:ring-green-400 focus:outline-none"
                 required>
        </div>
        <button type="submit"
                class="w-full py-3 rounded-xl font-semibold text-black 
                       bg-gradient-to-r from-green-400 to-emerald-500 shadow-md shadow-green-500/30
                       hover:scale-105 hover:shadow-lg hover:shadow-green-400/40 transition">
          🚀 Share Lunch
        </button>
      </form>

      <!-- Back Link -->
      <div class="text-center mt-6">
        <a href="dashboard.php" class="text-green-400 font-semibold hover:underline">⬅ Back to Dashboard</a>
      </div>
    </div>
  </main>

  <!-- Footer -->
  <footer class="py-4 text-center text-gray-400 border-t border-gray-700">
    🚀 Lunch Box | Developed by <b class="text-green-400">JANJIRALA KALYAN</b>
  </footer>

  <!-- Floating Animation -->
  <lottie-player 
    src="https://assets7.lottiefiles.com/private_files/lf30_editor_0aoyhd.json"
    background="transparent"
    speed="1"
    style="position:fixed; bottom:20px; right:20px; width:120px; height:120px; z-index:50"
    loop autoplay>
  </lottie-player>

</body>
</html>

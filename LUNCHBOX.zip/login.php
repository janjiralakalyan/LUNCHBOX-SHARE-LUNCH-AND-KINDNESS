<?php
session_start();
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $roll_number = trim($_POST['roll_number'] ?? '');
    $password = trim($_POST['password'] ?? '');

    // ✅ Validation
    if (empty($roll_number) || empty($password)) {
        $_SESSION['error'] = "⚠️ Please fill in all fields!";
        header("Location: login.html");
        exit();
    }

    // ✅ Fetch user by roll number (secure prepared statement)
    $sql = "SELECT id, name, roll_number, password FROM users WHERE roll_number = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        $_SESSION['error'] = "⚠️ Database error. Please try again later.";
        header("Location: login.html");
        exit();
    }

    $stmt->bind_param("s", $roll_number);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // ✅ Verify password
        if (password_verify($password, $user['password'])) {
            // Store session data
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['roll_number'] = $user['roll_number'];
            $_SESSION['name'] = $user['name'];

            // Redirect to dashboard
            header("Location: dashboard.php");
            exit();
        } else {
            $_SESSION['error'] = "❌ Invalid password!";
            header("Location: login.html");
            exit();
        }
    } else {
        $_SESSION['error'] = "❌ Roll number not found!";
        header("Location: login.html");
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>

<?php
session_start();
include 'connect.php';

// Check if logged in
if (!isset($_SESSION['roll_number'])) {
    echo "⚠️ You must be logged in to find lunch.";
    exit();
}

$my_roll = $_SESSION['roll_number'];

// Fetch available lunches (not shared by the logged-in user) + average rating
$sql = "SELECT s.*, u.name, u.phone,
        COALESCE(AVG(r.rating), 0) AS avg_rating,
        COUNT(r.id) AS total_reviews
        FROM shared_lunches s
        JOIN users u ON s.roll_number = u.roll_number
        LEFT JOIN reviews r ON r.sharer_roll = s.roll_number
        WHERE s.status = 'available' AND s.roll_number != ?
        GROUP BY s.id, u.name, u.phone";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $my_roll);
$stmt->execute();
$result = $stmt->get_result();

// Function to show stars
function getStars($rating) {
    $stars = "";
    for ($i = 1; $i <= 5; $i++) {
        $stars .= ($i <= round($rating)) ? "⭐" : "☆";
    }
    return $stars;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Find Lunch</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-gray-900 via-black to-gray-800 text-white min-h-screen flex flex-col">

  <!-- Header -->
  <header class="py-6 text-center border-b border-gray-700">
    <h1 class="text-3xl font-bold text-yellow-400 tracking-wide">🔍 Find Lunch</h1>
  </header>

  <!-- Main -->
  <main class="container mx-auto p-6 flex-1">

    <section class="bg-black/40 backdrop-blur-md rounded-2xl p-6 border border-gray-700 hover:border-yellow-400 transition">
      <h2 class="text-2xl font-semibold text-yellow-300 mb-4">🍱 Available Lunches</h2>

      <?php if ($result->num_rows > 0): ?>
        <div class="overflow-x-auto">
          <table class="w-full text-sm text-center">
            <thead class="bg-gray-800 text-yellow-300">
              <tr>
                <th class="px-4 py-2">Sharer</th>
                <th class="px-4 py-2">Roll No</th>
                <th class="px-4 py-2">Phone</th>
                <th class="px-4 py-2">Food Items</th>
                <th class="px-4 py-2">Location</th>
                <th class="px-4 py-2">Rating</th>
                <th class="px-4 py-2">Action</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-700">
              <?php while ($row = $result->fetch_assoc()): ?>
                <tr class="hover:bg-gray-800/50">
                  <td class="px-4 py-2 font-medium text-green-400"><?php echo htmlspecialchars($row['name']); ?></td>
                  <td class="px-4 py-2"><?php echo htmlspecialchars($row['roll_number']); ?></td>
                  <td class="px-4 py-2"><?php echo htmlspecialchars($row['phone']); ?></td>
                  <td class="px-4 py-2"><?php echo htmlspecialchars($row['food_items']); ?></td>
                  <td class="px-4 py-2"><?php echo htmlspecialchars($row['location']); ?></td>
                  <td class="px-4 py-2">
                    <span class="text-yellow-400 text-lg"><?php echo getStars($row['avg_rating']); ?></span>
                    <div class="text-gray-400 text-xs">(<?php echo $row['total_reviews']; ?> reviews)</div>
                  </td>
                  <td class="px-4 py-2">
                    <a href="accept_lunch.php?sharer_roll=<?php echo urlencode($row['roll_number']); ?>" 
                       class="px-4 py-2 bg-yellow-400 hover:bg-yellow-500 text-black font-semibold rounded-lg shadow">
                       Accept
                    </a>
                  </td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <p class="text-center text-gray-400 mt-6">No lunches available right now 🍽️</p>
      <?php endif; ?>

      <div class="mt-6 text-center">
        <a href="dashboard.php" class="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg shadow text-white">⬅ Back to Dashboard</a>
      </div>
    </section>

  </main>

  <!-- Footer -->
  <footer class="py-4 text-center text-gray-400 border-t border-gray-700">
    🚀 Lunch Box | Developed by <b class="text-green-400">JANJIRALA KALYAN</b>
  </footer>

</body>
</html>

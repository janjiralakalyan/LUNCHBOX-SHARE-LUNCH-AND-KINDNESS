<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['roll_number'])) {
    header("Location: login.html");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['lunch_id'])) {
    $roll_number = $_SESSION['roll_number'];
    $lunch_id = intval($_POST['lunch_id']);

    // Verify that this lunch was accepted by the logged-in user
    $checkQuery = "SELECT * FROM shared_lunches WHERE id = ? AND accepted_by = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("is", $lunch_id, $roll_number);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Reset lunch status back to available
        $updateQuery = "UPDATE shared_lunches SET status = 'available', accepted_by = NULL WHERE id = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("i", $lunch_id);
        if ($stmt->execute()) {
            header("Location: dashboard.php?msg=cancelled");
            exit();
        } else {
            echo "Error cancelling lunch.";
        }
    } else {
        echo "Invalid request.";
    }
} else {
    echo "Invalid request.";
}
?>
<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['roll_number'])) {
    header("Location: login.html");
    exit();
}

$roll_number = $_SESSION['roll_number'];

// ✅ Get user details
$userQuery = "SELECT * FROM users WHERE roll_number = ?";
$stmt = $conn->prepare($userQuery);
$stmt->bind_param("s", $roll_number);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// ✅ Fetch shared lunches
$sharedQuery = "SELECT * FROM shared_lunches WHERE roll_number = ?";
$stmt = $conn->prepare($sharedQuery);
$stmt->bind_param("s", $roll_number);
$stmt->execute();
$sharedLunches = $stmt->get_result();

// ✅ Fetch accepted lunches
$acceptedQuery = "SELECT s.*, u.name AS sharer_name, u.phone AS sharer_phone,
                  (SELECT COUNT(*) FROM reviews r WHERE r.lunch_id = s.id AND r.accepter_roll = ?) AS already_reviewed
                  FROM shared_lunches s 
                  JOIN users u ON s.roll_number = u.roll_number 
                  WHERE s.accepted_by = ?";
$stmt = $conn->prepare($acceptedQuery);
$stmt->bind_param("ss", $roll_number, $roll_number);
$stmt->execute();
$acceptedLunches = $stmt->get_result();

// ✅ Fetch notifications
$notifyQuery = "SELECT s.food_items, s.location, a.name AS accepter_name, a.roll_number AS accepter_roll, a.phone AS accepter_phone 
                FROM shared_lunches s 
                JOIN users a ON s.accepted_by = a.roll_number 
                WHERE s.roll_number = ? AND s.status = 'accepted'";
$stmt = $conn->prepare($notifyQuery);
$stmt->bind_param("s", $roll_number);
$stmt->execute();
$notifications = $stmt->get_result();

// ✅ Fetch my reviews
$myReviewsQuery = "SELECT r.*, u.name AS sharer_name 
                   FROM reviews r 
                   JOIN users u ON r.sharer_roll = u.roll_number
                   WHERE r.accepter_roll = ?";
$stmt = $conn->prepare($myReviewsQuery);
$stmt->bind_param("s", $roll_number);
$stmt->execute();
$myReviews = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - Lunch Box</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
</head>
<body class="bg-gradient-to-br from-gray-900 via-black to-gray-800 text-white min-h-screen flex flex-col">

  <!-- Header -->
  <header class="py-6 text-center border-b border-gray-700">
    <h1 class="text-3xl font-bold text-green-400 tracking-wide">
      👋 Welcome, <?php echo htmlspecialchars($user['name']); ?> (<?php echo $user['roll_number']; ?>)
    </h1>
  </header>

  <!-- Main Content -->
  <main class="container mx-auto p-6 flex-1 space-y-10">

    <!-- Shared Lunches -->
    <section class="bg-black/40 backdrop-blur-md rounded-2xl p-6 border border-gray-700 hover:border-green-400 transition">
      <div class="flex items-center justify-between mb-4">
        <h2 class="text-2xl font-semibold text-green-400">🍱 Shared Lunches</h2>
        <a href="sharelunch.php" class="px-4 py-2 bg-green-500 hover:bg-green-600 rounded-lg shadow text-black font-semibold">+ Share</a>
      </div>
      <div class="overflow-x-auto">
        <table class="w-full text-sm">
          <thead class="bg-gray-800 text-green-300">
            <tr>
              <th class="px-4 py-2">Food</th>
              <th class="px-4 py-2">Location</th>
              <th class="px-4 py-2">Status</th>
              <th class="px-4 py-2">Created</th>
              <th class="px-4 py-2">Action</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-700">
            <?php while($row = $sharedLunches->fetch_assoc()) { ?>
              <tr class="hover:bg-gray-800/50">
                <td class="px-4 py-2"><?php echo htmlspecialchars($row['food_items']); ?></td>
                <td class="px-4 py-2"><?php echo htmlspecialchars($row['location']); ?></td>
                <td class="px-4 py-2"><?php echo htmlspecialchars($row['status']); ?></td>
                <td class="px-4 py-2"><?php echo htmlspecialchars($row['created_at']); ?></td>
                <td class="px-4 py-2">
                  <form method="POST" action="cancel_shared_lunch.php">
                    <input type="hidden" name="lunch_id" value="<?php echo $row['id']; ?>">
                    <button type="submit" class="px-3 py-1 bg-red-500 hover:bg-red-600 rounded-lg">🗑 Cancel</button>
                  </form>
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </section>

    <!-- Accepted Lunches -->
    <section class="bg-black/40 backdrop-blur-md rounded-2xl p-6 border border-gray-700 hover:border-green-400 transition">
      <div class="flex items-center justify-between mb-4">
        <h2 class="text-2xl font-semibold text-yellow-400">✅ Accepted Lunches</h2>
        <a href="findlunch.php" class="px-4 py-2 bg-yellow-400 hover:bg-yellow-500 rounded-lg text-black font-semibold">🔍 Find Lunch</a>
      </div>
      <div class="overflow-x-auto">
        <table class="w-full text-sm">
          <thead class="bg-gray-800 text-yellow-300">
            <tr>
              <th class="px-4 py-2">Food</th>
              <th class="px-4 py-2">Location</th>
              <th class="px-4 py-2">Sharer</th>
              <th class="px-4 py-2">Phone</th>
              <th class="px-4 py-2">Action</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-700">
            <?php while($row = $acceptedLunches->fetch_assoc()) { ?>
              <tr class="hover:bg-gray-800/50">
                <td class="px-4 py-2"><?php echo htmlspecialchars($row['food_items']); ?></td>
                <td class="px-4 py-2"><?php echo htmlspecialchars($row['location']); ?></td>
                <td class="px-4 py-2"><?php echo htmlspecialchars($row['sharer_name']); ?> (<?php echo $row['roll_number']; ?>)</td>
                <td class="px-4 py-2"><?php echo htmlspecialchars($row['sharer_phone']); ?></td>
                <td class="px-4 py-2 space-x-2">
                  <?php if ($row['already_reviewed'] == 0): ?>
                    <form method="POST" action="submit_review.php" class="inline-flex space-x-2">
                      <input type="hidden" name="lunch_id" value="<?php echo $row['id']; ?>">
                      <input type="hidden" name="sharer_roll" value="<?php echo $row['roll_number']; ?>">
                      <select name="rating" class="bg-gray-900 border border-gray-600 rounded px-2" required>
                        <option value="">⭐</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                      </select>
                      <input type="text" name="comment" class="bg-gray-900 border border-gray-600 rounded px-2" placeholder="Review..." required>
                      <button type="submit" class="px-3 py-1 bg-yellow-400 hover:bg-yellow-500 text-black rounded-lg">Review</button>
                    </form>
                  <?php else: ?>
                    <span class="text-green-400 font-medium">✅ Reviewed</span>
                  <?php endif; ?>
                  <form method="POST" action="cancel_accepted_lunch.php" class="inline">
                    <input type="hidden" name="lunch_id" value="<?php echo $row['id']; ?>">
                    <button type="submit" class="px-3 py-1 bg-red-500 hover:bg-red-600 rounded-lg">❌ Cancel</button>
                  </form>
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </section>

    <!-- Notifications -->
    <section class="bg-black/40 backdrop-blur-md rounded-2xl p-6 border border-gray-700 hover:border-green-400 transition">
      <h2 class="text-2xl font-semibold text-blue-400 mb-4">🔔 Notifications</h2>
      <table class="w-full text-sm">
        <thead class="bg-gray-800 text-blue-300">
          <tr>
            <th class="px-4 py-2">Food</th>
            <th class="px-4 py-2">Location</th>
            <th class="px-4 py-2">Accepted By</th>
            <th class="px-4 py-2">Contact</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-700">
          <?php while($row = $notifications->fetch_assoc()) { ?>
            <tr class="hover:bg-gray-800/50">
              <td class="px-4 py-2"><?php echo htmlspecialchars($row['food_items']); ?></td>
              <td class="px-4 py-2"><?php echo htmlspecialchars($row['location']); ?></td>
              <td class="px-4 py-2"><?php echo htmlspecialchars($row['accepter_name']); ?> (<?php echo $row['accepter_roll']; ?>)</td>
              <td class="px-4 py-2"><?php echo htmlspecialchars($row['accepter_phone']); ?></td>
            </tr>
          <?php } ?>
        </tbody>
      </table>
    </section>

    <!-- My Reviews -->
    <section class="bg-black/40 backdrop-blur-md rounded-2xl p-6 border border-gray-700 hover:border-green-400 transition">
      <h2 class="text-2xl font-semibold text-pink-400 mb-4">⭐ My Reviews</h2>
      <table class="w-full text-sm">
        <thead class="bg-gray-800 text-pink-300">
          <tr>
            <th class="px-4 py-2">Sharer</th>
            <th class="px-4 py-2">Rating</th>
            <th class="px-4 py-2">Comment</th>
            <th class="px-4 py-2">Date</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-700">
          <?php while($row = $myReviews->fetch_assoc()) { ?>
            <tr class="hover:bg-gray-800/50">
              <td class="px-4 py-2"><?php echo htmlspecialchars($row['sharer_name']); ?> (<?php echo $row['sharer_roll']; ?>)</td>
              <td class="px-4 py-2"><?php echo htmlspecialchars($row['rating']); ?> ⭐</td>
              <td class="px-4 py-2"><?php echo htmlspecialchars($row['comment']); ?></td>
              <td class="px-4 py-2"><?php echo htmlspecialchars($row['created_at']); ?></td>
            </tr>
          <?php } ?>
        </tbody>
      </table>
    </section>

  </main>

  <!-- Footer -->
  <footer class="py-4 text-center text-gray-400 border-t border-gray-700">
    🚀 Lunch Box | Developed by <b class="text-green-400">JANJIRALA KALYAN</b>
  </footer>

  <!-- Floating Food Animation -->
  <lottie-player 
    src="https://assets7.lottiefiles.com/private_files/lf30_editor_0aoyhd.json"
    background="transparent"
    speed="1"
    style="position:fixed; bottom:20px; right:20px; width:120px; height:120px; z-index:50"
    loop autoplay>
  </lottie-player>

</body>
</html>
